export const mapAlbums = ({ id, name, year }) => ({
    id,
    name,
    year,
});