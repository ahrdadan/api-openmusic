export const mapSongs = ({ id, title, year, genre, performer, duration, albumId }) => ({
    id,
    title,
    year,
    genre,
    performer,
    duration,
    albumId,
});